This repo contains a java File `FunctionClass` that does three things:
1. unzip an archive containing a list of text files
2. merge the extracted text files into a new file
3. zip the three original files together with the merged file into a new archive

An archive for testing the script is given with `archive.zip` containing the files `file[1-3].zip`
